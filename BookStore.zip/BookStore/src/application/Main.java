package application;

import controllers.LoginController;
import models.Author;
import models.Role;
import models.User;
import views.LoginView;
import views.MainView;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.*;

public class Main extends Application {

    public static void main(String[] args) {
        seedData();
        launch(args);
    }

    private static void seedData() {
        User admin = new User("admin", "admin0001", Role.ADMIN);
        User manager = new User("manager", "manager0002", Role.MANAGER);
        User librarian = new User("librarian", "librarian0003", Role.LIBRARIAN);
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(User.FILE_PATH));
            outputStream.writeObject(admin);
            outputStream.writeObject(manager);
            outputStream.writeObject(librarian);
            System.out.println("WELL DONE, all users are written into the file :)");
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
    }
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(Author.FILE_PATH))) {
            outputStream.writeObject(new Author("Nita", "Prose"));
            outputStream.writeObject(new Author("Matt", "Haig"));
            outputStream.writeObject(new Author("Amor", "Towles"));
            outputStream.writeObject(new Author("James", "Patterson"));
            outputStream.writeObject(new Author("Laura", "Dave"));
            outputStream.writeObject(new Author("John", "Grisham"));
            outputStream.writeObject(new Author("John", "Darnielle"));
            outputStream.writeObject(new Author("Isaac", "Hendrick"));
            outputStream.writeObject(new Author("Mighty", "Allen"));
            outputStream.writeObject(new Author("Morgan", "Forder"));
            outputStream.writeObject(new Author("Jack", "Frost"));
            
            System.out.println("PERFECT, all authors are written into the file :)");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void start(Stage stage) {
        LoginView loginView = new LoginView();
        LoginController controller = new LoginController(loginView, new MainView(stage), stage);
        Image icon = new Image("books.png");
        stage.getIcons().add(icon);
        Scene scene = new Scene(loginView.getView(), 1080, 640); 
        stage.setTitle("The Strand - A room without books is like a body without a soul.");
        stage.setScene(scene);
        stage.show();
    }
}
