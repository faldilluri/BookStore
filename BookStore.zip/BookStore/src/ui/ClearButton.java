package ui;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class ClearButton extends Button {
    public ClearButton() {
        super.setText("Clear");
    }
}
