package ui;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class SearchButton extends Button {
    public SearchButton() {
        super.setText("Search");
    }
}
