package controllers;

import models.User;
import views.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainController {
    private final MainView mainView;
    private final Stage mainStage;

    public MainController(MainView mainView, Stage mainStage) {
        this.mainView = mainView;
        this.mainStage = mainStage;
        setListener();

    }
    private Tab openTab(Tab tab){
        for(Tab t:mainView.getTabPane().getTabs()){
            if(t.getText().equals(tab.getText())){
                return t;
            }
        }
        mainView.getTabPane().getTabs().add(tab);
        return tab;
    }

    private void setListener() {

        mainView.getViewAuthors().setOnAction((e)-> {
            Tab authorTab = new Tab("Authors");
            authorTab.setContent(new AuthorView().getView());
            Tab tab=openTab(authorTab);
        });

        mainView.getViewBooks().setOnAction((e)-> {
            Tab booksTab = new Tab("Books");
            booksTab.setContent(new BookView().getView());
            Tab tab=openTab(booksTab);
        });
        
        mainView.getNewBill().setOnAction(e->{
            Tab order = new Tab("New Order");
            order.setContent(new NewOrderView(mainView, order).getView());
            Tab tab=openTab(order);
        });
        
        mainView.getOrdersMenu().setOnAction(e->{
            Tab sales = new Tab("Order Graphics");
            sales.setContent(new StatsView().getView());
            Tab tab=openTab(sales);
        });
       
        mainView.getStatsMenu().setOnAction(e->{
            Tab sales = new Tab("Sales Graphics");
            sales.setContent(new StatsView().getView2());
            Tab tab=openTab(sales);
        });
        
        mainView.getManageUsers().setOnAction(e->{
            Tab users = new Tab("Users");
            users.setContent(new UsersView().getView());
            Tab tab=openTab(users);
        });

        mainView.getLogoutMenuLabel().setOnMouseClicked((e)->{
            LoginView loginView = new LoginView();
            new LoginController(loginView, new MainView(mainStage), mainStage);
            Scene scene = new Scene(loginView.getView(), 1080, 640);
            mainStage.setScene(scene);
        });
    }
}
