package views;

import controllers.AuthorController;
import controllers.StatsController;
import models.Author;
import models.Book;
import models.BookOrder;
import models.Order;
import ui.CreateButton;
import ui.DeleteButton;
import ui.EditButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class StatsView extends View{
	
    private final VBox vBox = new VBox();

    public StatsView() {
        new StatsController(this);
    }

    public Parent getView2() {
        vBox.setSpacing(10);
        vBox.setAlignment(Pos.CENTER);
        
        Image img = new Image("stats.png");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundPosition.CENTER,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        vBox.setBackground(bGround);


        ArrayList<Order> orders = Order.getOrders();
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        for(Order o : orders) {
            int match=0;
            for (PieChart.Data d: pieChartData) {
                if (o.getClientName().matches(d.getName())) {
                    d.setPieValue(d.getPieValue()+o.getTotal());
                    match=1;
                    break;
                }
            }
            if (match==0) {
                pieChartData.add(new PieChart.Data(o.getClientName(), o.getTotal()));
            }
        }
        final PieChart chart = new PieChart(pieChartData);
        
        chart.setTitle("Graphic Representation of Sales");
        chart.setStyle("-fx-font-weight: bold;");
        

        vBox.getChildren().addAll(chart);
        return vBox;
    }
    
    public Parent getView() {
        vBox.setSpacing(10);
        vBox.setAlignment(Pos.CENTER);
        
        Image img = new Image("stats.png");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundPosition.CENTER,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        vBox.setBackground(bGround);

        Order.getOrders().clear();
        ArrayList<Order> orders = Order.getOrders();

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        for(Order o : orders) {
            for (BookOrder b: o.getBooksOrdered()){
                int match=0;
                for (PieChart.Data d: pieChartData) {
                    if (b.getTitle().matches(d.getName())) {
                        d.setPieValue(d.getPieValue() + b.getQuantity());
                        match = 1;
                        break;
                    }
                }
                if (match==0) {
                    pieChartData.add(new PieChart.Data(b.getTitle(), b.getQuantity()));
                }
            }
        }
        
        for (PieChart.Data d: pieChartData){
            System.out.println(d.getName()+" "+d.getPieValue());
        }
        final PieChart chart = new PieChart(pieChartData);

        chart.setTitle("Graphic Representation of Orders");
        chart.setStyle("-fx-font-weight: bold;");

        vBox.getChildren().addAll(chart);

        return vBox;
    }
}
