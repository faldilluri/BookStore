package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class LoginView extends View {
    private final BorderPane borderPane = new BorderPane();

    private final TextField usernameField = new TextField();

    private final PasswordField passwordField = new PasswordField();
    private final Button loginBtn = new Button("Login");
    private final Label errorLabel = new Label("");
    public TextField getUsernameField() {
        return usernameField;
    }

    public PasswordField getPasswordField() {
        return passwordField;
    }

    public Button getLoginBtn() {
        return loginBtn;
    }
    public Label getErrorLabel() {
        return errorLabel;
    }
    public LoginView() {
        setView();
    }

    private void setView() {
    	
        Label usernameLabel = new Label("Username", usernameField);
        Label passwordLabel = new Label("Password", passwordField);
        Label welcome = new Label("Welcome to The Strand bookstore :)");
        Label philosophy = new Label ("Our philosophy:");
        Label enjoy = new Label("Enjoy!");
        Label moto = new Label("Outside of a dog, a book is a man's best friend.");
        VBox vBox = new VBox();
        
        usernameLabel.setFont(Font.font("Bookman Old Style",FontWeight.BOLD,12));
        passwordLabel.setFont(Font.font("Bookman Old Style",FontWeight.BOLD,12));
        welcome.setFont(Font.font("Brush Script MT",FontWeight.BOLD,55));
        philosophy.setFont(Font.font("Brush Script MT",FontWeight.BOLD,30));
        moto.setFont(Font.font("Brush Script MT",FontWeight.BOLD,30));
        enjoy.setFont(Font.font("Brush Script MT",FontWeight.BOLD,30));
        
        usernameLabel.setTextFill(Color.ALICEBLUE);
        passwordLabel.setTextFill(Color.ALICEBLUE);
        welcome.setTextFill(Color.ALICEBLUE);
        philosophy.setTextFill(Color.ALICEBLUE);
        moto.setTextFill(Color.ALICEBLUE);
        enjoy.setTextFill(Color.ALICEBLUE);
        
        vBox.getChildren().addAll(welcome,philosophy,moto,usernameLabel,passwordLabel,enjoy,loginBtn,errorLabel);
        
        Image img = new Image("beautyandbeast.png");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundPosition.CENTER,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        borderPane.setBackground(bGround);

        vBox.setAlignment(Pos.CENTER);
        vBox.setPadding(new Insets(20));
        vBox.setSpacing(15);
        borderPane.setCenter(vBox);
    }
    @Override
    public Parent getView() {
        return borderPane;
    }
}
