package views;

import controllers.BookController;
import models.Author;
import models.Book;
import models.Role;
import ui.CreateButton;
import ui.DeleteButton;
import ui.EditButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.converter.FloatStringConverter;

import java.util.ArrayList;
import java.util.List;

public class BookView extends View{
    private final BorderPane borderPane = new BorderPane();
    private final TableView<Book> tableView = new TableView<>();
    private final HBox formPane = new HBox();
    private final TextField field_isbn = new TextField();
    private final TextField field_title = new TextField();
    private final TextField field_purchased = new TextField();
    private final TextField field_selling = new TextField();
    private final TextField field_stock = new TextField();
    private final ComboBox<Author> authorsComboBox = new ComboBox<>();
    private final Button button_save = new CreateButton();
    private final Button button_delete = new DeleteButton();
    private final TableColumn<Book, String> column_isbn = new TableColumn<>("ISBN");
    private final TableColumn<Book, String> column_title = new TableColumn<>("Title");
    private final TableColumn<Book, Float> column_purchased = new TableColumn<>("Purchased Price");
    private final TableColumn<Book, Float> column_selling = new TableColumn<>("Selling Price");
    private final TableColumn<Book, String> column_author = new TableColumn<>("Author");
    private final TableColumn<Book, Integer> column_stock = new TableColumn<>("Stock");
    private final Label resultLabel = new Label("");
    private final SearchView searchView = new SearchView("Tell me the book, I'm waiting...");

    public TableView<Book> getTableView() {
        return tableView;
    }

    public TextField getIsbnField() {
        return field_isbn;
    }

    public TextField getTitleField() {
        return field_title;
    }

    public TextField getPurchasedPriceField() {
        return field_purchased;
    }

    public TextField getSellingPriceField() {
        return field_selling;
    }
    public TextField getStockField() {
    	return field_stock;
    }

    public ComboBox<Author> getAuthorsComboBox() {
        return authorsComboBox;
    }

    public Button getSaveBtn() {
        return button_save;
    }

    public Button getDeleteBtn() {
        return button_delete;
    }

    public TableColumn<Book, String> getIsbnCol() {
        return column_isbn;
    }

    public TableColumn<Book, String> getTitleCol() {
        return column_title;
    }

    public TableColumn<Book, Float> getPurchasedPriceCol() {
        return column_purchased;
    }

    public TableColumn<Book, Float> getSellingPriceCol() {
        return column_selling;
    }
    
    public TableColumn<Book, Integer> getStockCol() {
        return column_stock;
    }

    public Label getResultLabel() {
        return resultLabel;
    }

    public SearchView getSearchView() {
        return searchView;
    }

    public BookView() {
        setTableView();
        setForm();
        new BookController(this);
    }

    private void setForm() {
    	
        formPane.setPadding(new Insets(20));
        formPane.setSpacing(20);
        formPane.setAlignment(Pos.CENTER);
        
        Label isbnLabel = new Label("ISBN", field_isbn);
        isbnLabel.setContentDisplay(ContentDisplay.TOP);
        
        Label titleLabel = new Label("Title", field_title);
        titleLabel.setContentDisplay(ContentDisplay.TOP);
        
        Label purchasedPriceLabel = new Label("Purchased price", field_purchased);
        purchasedPriceLabel.setContentDisplay(ContentDisplay.TOP);
        
        Label sellingPriceLabel = new Label("Selling price", field_selling);
        sellingPriceLabel.setContentDisplay(ContentDisplay.TOP);
        
        Label stockLabel = new Label("Stock",field_stock);
        stockLabel.setContentDisplay(ContentDisplay.TOP);
        
        Label authorLabel = new Label("Author", authorsComboBox);
        
        authorsComboBox.getItems().setAll(Author.getAuthors());
        
        if (!Author.getAuthors().isEmpty())
            authorsComboBox.setValue(Author.getAuthors().get(0));
        authorLabel.setContentDisplay(ContentDisplay.TOP);
        formPane.getChildren().addAll(stockLabel,isbnLabel, titleLabel, purchasedPriceLabel, sellingPriceLabel,
                                        authorLabel, button_save, button_delete);
    }

    private void setTableView() {
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        tableView.setEditable(true);
        tableView.setItems(FXCollections.observableArrayList(Book.getBooks()));

        column_stock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        
        column_isbn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        column_isbn.setCellFactory(TextFieldTableCell.forTableColumn());

        column_title.setCellValueFactory(new PropertyValueFactory<>("title"));
        column_title.setCellFactory(TextFieldTableCell.forTableColumn());

        column_purchased.setCellValueFactory(new PropertyValueFactory<>("purchasedPrice"));
        column_purchased.setCellFactory(TextFieldTableCell.forTableColumn(new FloatStringConverter()));

        column_selling.setCellValueFactory(new PropertyValueFactory<>("sellingPrice"));
        column_selling.setCellFactory(TextFieldTableCell.forTableColumn(new FloatStringConverter()));

        column_author.setCellValueFactory(new PropertyValueFactory<>("author"));

        tableView.getColumns().addAll(column_stock,column_isbn, column_title, column_purchased, column_selling, column_author);
    }


    @Override
    public Parent getView() {
        borderPane.setCenter(tableView);

        if ((super.getCurrentUser().getRole() == Role.ADMIN) || (super.getCurrentUser().getRole() == Role.MANAGER)) {
            VBox vBox = new VBox();
            vBox.setAlignment(Pos.CENTER);
            vBox.setSpacing(5);
            vBox.getChildren().addAll(formPane, resultLabel);
            borderPane.setBottom(vBox);
        }
        
        Image img = new Image("beautyandbeast.png");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundRepeat.NO_REPEAT,
                                                   BackgroundPosition.CENTER,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        borderPane.setBackground(bGround);


        borderPane.setTop(searchView.getSearchPane());
        return borderPane;
    }
}
