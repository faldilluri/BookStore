package views;

import controllers.MainController;
import models.Role;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MainView extends View {
    private final MenuBar menuBar = new MenuBar();

    private final Menu booksMenu= new Menu("Books");
    private final MenuItem viewBooks = new MenuItem("Show book list");
    private final MenuItem viewAuthors = new MenuItem("Show only authors list");

    private final Menu salesMenu= new Menu("Sales");
    private final MenuItem newBill = new MenuItem("Generate a new bill");
    private final MenuItem statsMenu = new MenuItem("Graphic representation of sales");
    private final MenuItem ordersMenu = new MenuItem("Graphic representation of orders");

    private final Label logoutMenuLabel = new Label("Logout");
    private final Menu logoutMenu = new Menu("", logoutMenuLabel);

    private final Menu adminMenu = new Menu("Managing");
    private final MenuItem manageUsers = new MenuItem("Add/Remove/Edit Users");

    public MainView(Stage mainStage){
        new MainController(this, mainStage);
    }


    private final TabPane tabPane = new TabPane();

    @Override
    public Parent getView() {
        BorderPane borderPane = new BorderPane();

        booksMenu.getItems().addAll(viewBooks, viewAuthors);
        salesMenu.getItems().add(newBill);
        menuBar.getMenus().addAll(booksMenu, salesMenu, logoutMenu);


        Tab defaultTab = new Tab("Books");
        defaultTab.setContent(new BookView().getView());

        Role currentRole = (getCurrentUser() != null ? getCurrentUser().getRole() : null);
        if (currentRole != null) {
            if (currentRole == Role.ADMIN) {
                menuBar.getMenus().add(adminMenu);
                adminMenu.getItems().addAll(manageUsers);
            }
            if (currentRole == Role.MANAGER || currentRole == Role.ADMIN) {

                salesMenu.getItems().add(statsMenu);
                salesMenu.getItems().add(ordersMenu);
            }
            
            tabPane.getTabs().add(defaultTab);
        }

        VBox topPane = new VBox();
        topPane.getChildren().addAll(menuBar, tabPane);
        borderPane.setTop(topPane);
        
        borderPane.setBottom(new StackPane(new Text(getCurrentUser().getUsername().toUpperCase() + ", welcome to The Strand")));
              
        return borderPane;
    }


    public MenuBar getMenuBar() {
        return menuBar;
    }

    public Menu getBooksMenu() {
        return booksMenu;
    }

    public MenuItem getViewBooks() {
        return viewBooks;
    }

    public MenuItem getViewAuthors() {
        return viewAuthors;
    }

    public Menu getSalesMenu() {
        return salesMenu;
    }

    public MenuItem getNewBill() {
        return newBill;
    }

    public Menu getLogoutMenu() {
        return logoutMenu;
    }

    public Menu getAdminMenu() {
        return adminMenu;
    }

    public MenuItem getManageUsers() {
        return manageUsers;
    }


    public MenuItem getStatsMenu() {
        return statsMenu;
    }
    
   public MenuItem getOrdersMenu() {
    	return ordersMenu;
    }

    public Label getLogoutMenuLabel() {
        return logoutMenuLabel;
    }

    public TabPane getTabPane() {
        return tabPane;
    }

}
