package controllers;

import models.Author;
import models.Book;
import models.BookOrder;
import models.Order;
import views.BookView;
import views.NewOrderView;
import javafx.scene.control.Alert;
import javafx.scene.paint.Color;

import java.util.List;

public class OrderController {
	
    private final NewOrderView orderView;

    public OrderController(NewOrderView bookView) {
        this.orderView = bookView;
        Order.getOrders();
        setEditListener();
        setChooseBookListener();
        setRemoveBookListener();
        setCreateListener();
    }

    private void setChooseBookListener(){
        orderView.getBooks_tableView().setOnMousePressed(e->{
                if (e.isPrimaryButtonDown() && e.getClickCount() == 2) {
                    BookOrder b = new BookOrder(1, orderView.getBooks_tableView().getSelectionModel().getSelectedItem());
                    orderView.getOrder().getBooksOrdered().add(b);
                    orderView.getBooks_tableView().getItems().remove(orderView.getBooks_tableView().getSelectionModel().getSelectedItem());
                    orderView.getTableView().getItems().add(b);
                    orderView.getTotalValueLabel().setText(((Float)orderView.getOrder().getTotal()).toString());
                }
        });
    }

    private void setRemoveBookListener(){
        orderView.getTableView().setOnMousePressed(e->{
            if (e.isPrimaryButtonDown() && e.getClickCount() == 2) {
                BookOrder b = orderView.getTableView().getSelectionModel().getSelectedItem();
                orderView.getOrder().getBooksOrdered().remove(b);
                orderView.getBooks_tableView().getItems().add(b.getBook());
                orderView.getTableView().getItems().remove(b);
                orderView.getTotalValueLabel().setText(((Float)orderView.getOrder().getTotal()).toString());
            }
        });
    }

    private void setEditListener() {
        orderView.getNoCol().setOnEditCommit(event -> {
            BookOrder bookOrderToEdit = event.getRowValue();
            int valueReplaced = bookOrderToEdit.getQuantity();
                if(event.getNewValue() < bookOrderToEdit.getStock()) {
                    bookOrderToEdit.setQuantity(event.getNewValue());
                }
                else {
                    orderView.getResultLabel().setText("Hehe sorry, but The Strand doesn't have this quantity of books in stock :(");
                    orderView.getResultLabel().setTextFill(Color.RED);
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.show();
                }

            if (bookOrderToEdit.getQuantity() > 0){
                System.out.println(orderView.getOrder().getBooksOrdered());
                orderView.getTotalPriceCol().setText(((Float)orderView.getOrder().getTotal()).toString());
            }
            else {
                bookOrderToEdit.setQuantity(valueReplaced);
                orderView.getTableView().getItems().set(orderView.getTableView().getItems().indexOf(bookOrderToEdit), bookOrderToEdit);
                orderView.getResultLabel().setText("Try to enter a new value :)");
                orderView.getResultLabel().setTextFill(Color.GREEN);
            }
        });

    }

    private void setCreateListener() {
        orderView.getSaveBtn().setOnMousePressed(e -> {

            orderView.getOrder().completeOrder(orderView.getNameField().getText());
            if (orderView.getOrder().saveInFile()) {
                orderView.getOrder().print();
                orderView.getResultLabel().setText("Your order is created :)");
                orderView.getResultLabel().setTextFill(Color.GREEN);

                for(BookOrder b: orderView.getOrder().getBooksOrdered()){
                    b.getBook().setStock(b.getBook().getStock() - b.getQuantity());
                    orderView.getBooks_tableView().getItems().remove(b.getBook());
                    orderView.getBooks_tableView().getItems().add(b.getBook());
                    b.getBook().updateFile();

                }
                resetFields();
            }
            else {
                orderView.getResultLabel().setText("The client name is not right! Enter the full name.");
                orderView.getResultLabel().setTextFill(Color.YELLOW);
            }
        });
    }
    private void resetFields() {
        orderView.getNameField().setText("");
    }
}