package controllers;

import models.Author;
import views.AuthorView;
import views.StatsView;
import javafx.collections.FXCollections;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class StatsController {
    private StatsView statsView;
    public StatsController(StatsView statsView) {
        this.statsView = statsView;
    }
}
