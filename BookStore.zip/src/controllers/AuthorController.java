package controllers;

import auxiliaries.FileHandler;
import models.Author;
import models.Book;
import views.AuthorView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AuthorController {
    private AuthorView authorView;
    public AuthorController(AuthorView authorView) {
        this.authorView = authorView;
        setSaveListener();
        setDeleteListener();
        setEditListener();
        setSearchListener();
    }

    private void setEditListener() {
        authorView.getFirstNameCol().setOnEditCommit(e -> {
            Author authorToEdit = e.getRowValue();
            String oldVal=authorToEdit.getFirstName();
            authorToEdit.setFirstName(e.getNewValue());
            if (authorToEdit.isValid()){
                authorToEdit.updateFile();
            }
            else {
                System.out.println("This author was unable to be edited "+e.getNewValue()+" :(");
                authorToEdit.setFirstName(oldVal);
                authorView.getTableView().getItems().set(authorView.getTableView().getItems().indexOf(authorToEdit), authorToEdit);
                authorView.getResultLabel().setText("Invalid edit :(");
                authorView.getResultLabel().setTextFill(Color.RED);
            }
        });

        authorView.getLastNameCol().setOnEditCommit(e -> {
            Author authorToEdit = e.getRowValue();
            String oldVal=authorToEdit.getLastName();
            authorToEdit.setLastName(e.getNewValue());
            if (authorToEdit.isValid()){
                authorToEdit.updateFile();
            }
            else {
                System.out.println("Author cannot be edited "+e.getNewValue());
                authorToEdit.setLastName(oldVal);
                authorView.getTableView().getItems().set(authorView.getTableView().getItems().indexOf(authorToEdit), authorToEdit);
                authorView.getResultLabel().setText("Edit did not succed");
                authorView.getResultLabel().setTextFill(Color.RED);
            }
        });
    }

    private void setSearchListener() {
        authorView.getSearchView().getClearBtn().setOnAction(e -> {
            authorView.getSearchView().getSearchField().setText("");
            authorView.getTableView().setItems(FXCollections.observableArrayList(Author.getAuthors()));
        });
        authorView.getSearchView().getSearchBtn().setOnAction(e -> {
            String searchText = authorView.getSearchView().getSearchField().getText();
            ArrayList<Author> searchResults = Author.getSearchResults(searchText);
            authorView.getTableView().setItems(FXCollections.observableArrayList(searchResults));
        });
    }

    private void setDeleteListener() {
        authorView.getDeleteBtn().setOnAction(e->{
            List<Author> itemsToDelete = List.copyOf(authorView.getTableView().getSelectionModel().getSelectedItems());
            for (Author a: itemsToDelete) {
                if (a.deleteFromFile()) {
                    authorView.getTableView().getItems().remove(a);
                    System.out.println("The author: "+a.getFullName()+" is now out :)");
                    authorView.getResultLabel().setText("His book is out as well :)");
                    authorView.getResultLabel().setTextFill(Color.GREEN);
                } else {
                    System.out.println("Sorry, cannot delete this book: "+a.getFullName()+" :(");
                    authorView.getResultLabel().setText("Ups, book is still there");
                    authorView.getResultLabel().setTextFill(Color.RED);
                    break;
                }
            }
        });
    }

    private void setSaveListener() {
        authorView.getSaveBtn().setOnAction(e -> {
            String firstName = authorView.getFirstNameField().getText();
            String lastName = authorView.getLastNameField().getText();
            Author author = new Author(firstName, lastName);
            if (!author.exists()) {
                if (author.saveInFile()) {
                    authorView.getTableView().getItems().add(author);
                    authorView.getResultLabel().setText("Yay, you created the author :)");
                    authorView.getResultLabel().setTextFill(Color.GREEN);
                    authorView.getFirstNameField().setText("");
                    authorView.getLastNameField().setText("");
                } else {
                    authorView.getResultLabel().setText("Aww crap, the author didn't showed up :(");
                    authorView.getResultLabel().setTextFill(Color.RED);
                }
            }
            else {
                authorView.getResultLabel().setText("Heyy you, there cannot be 2 authors with the same name!!!");
                authorView.getResultLabel().setTextFill(Color.RED);
            }
        });
    }
}
